public class Calculator{

public void add(int i, int j){
   int result = i+j;
   //String name = null;
   //name.toString();
}

private void hello(){
   System.out.println("Welcome");
}


}
